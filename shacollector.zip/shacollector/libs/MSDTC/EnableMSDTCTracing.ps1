# Powershell script to enable/disable MSDTC tracing
$disableAll = 0x00  
$enableAll = 0xFF 
$value = $enableAll  # $enableAll is used by default. You can use $disableAll here in order to disable tracing
$logfolder = "C:\mslog\DTCTrace"
$options = ("TRACE_MISC",
            "TRACE_CM",
            "TRACE_TRACE",
            "TRACE_SVC",
            "TRACE_GATEWAY",
            "TRACE_UI",
            "TRACE_CONTACT",
            "TRACE_UTIL",
            "TRACE_CLUSTER",
            "TRACE_RESOURCE",
            "TRACE_TIP",
            "TRACE_XA",
            "TRACE_LOG",
            "TRACE_MTXOCI",
            "TRACE_ETWTRACE",
            "TRACE_PROXY",
            "TRACE_KTMRM",
            "TRACE_VSSBACKUP",
            "TRACE_PERFMON",
            "TRACE_WMI")
            
$options | foreach {
    $property = $_
    set-itemproperty "HKLM:\SOFTWARE\Microsoft\MSDTC\Tracing\Sources" -name $property -Value $value
}
 
set-itemproperty "HKLM:\SOFTWARE\Microsoft\MSDTC\Tracing\Output" -name TraceFilePath -Value $logfolder

#FYI, ImageNameInTraceFileNameEnabled works only for Windows 10 OS or above
set-itemproperty "HKLM:\SOFTWARE\Microsoft\MSDTC\Tracing\Output" -name ImageNameInTraceFileNameEnabled -Value 0x1

# Create trace log folder
if(!(Test-Path -LiteralPath $logfolder)){
        New-Item $logfolder -ItemType Directory | Out-Null
}        

# Need to restart MSDTC service twice to create trace log files for the operation of initializing transaction manager
Net stop msdtc 
Net start msdtc
Net stop msdtc 
Net start msdtc
